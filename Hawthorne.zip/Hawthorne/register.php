<?php  
   	
	   $username = $_POST["username"];
	   $password = $_POST["password"];
	   
	   //connect with database
	   $conn = new mysqli("localhost","root","","find_francis");
	   if ($conn -> connect_error){
	   	echo "Error connecting please try again later";
	   }
	   else{
		   	//insert record in database
		   	$query = "insert into users(username,password) values ".
		   			"('$username','$password')";
					var_dump($username);
			if($conn -> query($query) === TRUE){
				//it is used to redirect to some other page its an in built funtion syntax should always be Location: l caps and no space before :
				header("Location: index.html");
			}
			else {
				header("Location: login_register_modal.html");
			}
	   }
      ?>